<?php require_once('Connections/conexion.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE taller SET nit=%s, nombre=%s, telefono=%s, direccion=%s, email=%s WHERE id=%s",
                       GetSQLValueString($_POST['nit'], "text"),
                       GetSQLValueString($_POST['nombre'], "text"),
                       GetSQLValueString($_POST['telefono'], "text"),
                       GetSQLValueString($_POST['direccion'], "text"),
                       GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_conexion, $conexion);
  $Result1 = mysql_query($updateSQL, $conexion) or die(mysql_error());

  $updateGoTo = "Listado_taller.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_Recordset1 = "-1";
if (isset($_GET['id'])) {
  $colname_Recordset1 = $_GET['id'];
}
mysql_select_db($database_conexion, $conexion);
$query_Recordset1 = sprintf("SELECT * FROM taller WHERE id = %s", GetSQLValueString($colname_Recordset1, "int"));
$Recordset1 = mysql_query($query_Recordset1, $conexion) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="description" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/bootstrap.min.css">
	    

  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" type="text/css" href="bootstrap-social.css">

<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<script type="text/javascript" src="js/jquery.mobile.customized.min.js"></script>
		<script type="text/javascript" src="js/jquery.easing.1.3.js"></script> 
		<script type="text/javascript" src="js/camera.min.js"></script>
		<script type="text/javascript" src="js/myscript.js"></script>
		<script src="js/sorting.js" type="text/javascript"></script>
		<script src="js/jquery.isotope.js" type="text/javascript"></script>

		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
		<link rel='stylesheet' id='camera-css'  href='css/camera.css' type='text/css' media='all'>

		

	  
	<title></title>

<nav class="navbar navbar-leon" role="navigation">

<center><h2>MODIFICAR CONDUCTOR</h2>

<body>

<p>&nbsp;</p>


<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
 <table width="100" border="1" class="table table-striped">
	      <tr>
	        <td width="42%"> 
            <input type="text" name="nit" class="form-control" id="documento" value="<?php echo htmlentities($row_Recordset1['nit'], ENT_COMPAT, ''); ?>"
             placeholder="Nit taller">
             
            </td>
	        <td width="58%"><input type="text" name="nombre" class="form-control" id="nombres" value="<?php echo htmlentities($row_Recordset1['nombre'], ENT_COMPAT, ''); ?>"
             placeholder="Nombre taller"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="telefono" class="form-control" id="apellidos" value="<?php echo htmlentities($row_Recordset1['telefono'], ENT_COMPAT, ''); ?>"
             placeholder="telefono"></td>
	        <td><input type="text" name="direccion" class="form-control" id="direccion" value="<?php echo htmlentities($row_Recordset1['direccion'], ENT_COMPAT, ''); ?>"
             placeholder="direccion"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="email" class="form-control" id="telefono" value="<?php echo htmlentities($row_Recordset1['email'], ENT_COMPAT, ''); ?>"
             placeholder="Email"></td>
             
	        <td><input name="regrc" type="submit" class="btn btn-primary" value="Guardar   Informacion" id="regrc"></td>
        
	        
	      	              
                     
	        <td>&nbsp;</td>
          </tr>
</table>
  <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="id" value="<?php echo $row_Recordset1['id']; ?>" />
</form>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
