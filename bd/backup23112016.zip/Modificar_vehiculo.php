<?php require_once('Connections/conexion.php'); ?>
<?php include 'main.php';?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE vehiculo1 SET placa=%s, marca=%s, modelo=%s, numero_motor=%s, serie_motor=%s, color_vehiculo=%s, capacidad=%s, numero_ejes=%s, tarjeta=%s, soat_numero=%s, fechav_soat=%s, valor_soat=%s, compania_soat=%s WHERE id=%s",
                       GetSQLValueString($_POST['placa'], "text"),
                       GetSQLValueString($_POST['marca'], "text"),
                       GetSQLValueString($_POST['modelo'], "text"),
                       GetSQLValueString($_POST['numero_motor'], "text"),
                       GetSQLValueString($_POST['serie_motor'], "text"),
                       GetSQLValueString($_POST['color_vehiculo'], "text"),
                       GetSQLValueString($_POST['capacidad'], "text"),
                       GetSQLValueString($_POST['numero_ejes'], "text"),
                       GetSQLValueString($_POST['tarjeta'], "text"),
                       GetSQLValueString($_POST['soat_numero'], "text"),
                       GetSQLValueString($_POST['fechav_soat'], "text"),
                       GetSQLValueString($_POST['valor_soat'], "text"),
                       GetSQLValueString($_POST['compania_soat'], "text"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_conexion, $conexion);
  $Result1 = mysql_query($updateSQL, $conexion) or die(mysql_error());

  $updateGoTo = "Detalle_vehiculo.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_Recordset1 = "-1";
if (isset($_GET['id'])) {
  $colname_Recordset1 = $_GET['id'];
}
mysql_select_db($database_conexion, $conexion);
$query_Recordset1 = sprintf("SELECT * FROM vehiculo1 WHERE id = %s", GetSQLValueString($colname_Recordset1, "int"));
$Recordset1 = mysql_query($query_Recordset1, $conexion) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="description" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/bootstrap.min.css">
	    

  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" type="text/css" href="bootstrap-social.css">

<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<script type="text/javascript" src="js/jquery.mobile.customized.min.js"></script>
		<script type="text/javascript" src="js/jquery.easing.1.3.js"></script> 
		<script type="text/javascript" src="js/camera.min.js"></script>
		<script type="text/javascript" src="js/myscript.js"></script>
		<script src="js/sorting.js" type="text/javascript"></script>
		<script src="js/jquery.isotope.js" type="text/javascript"></script>

		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
		<link rel='stylesheet' id='camera-css'  href='css/camera.css' type='text/css' media='all'>

		
 
	<title></title>


<script language=javascript>
function ventanaSecundaria (URL){
   window.open(URL,"ventana1","width=720,height=590,scrollbars=NO")
}
</script>
			

</head>

<body class="as">



<center><h2>MODIFICAR CAMION</h2>

  <!-- El logotipo y el icono que despliega el menú se agrupan
       para mostrarlos mejor en los dispositivos móviles -->
 

<!-- Agrupar los enlaces de navegación, los formularios y cualquier
       otro elemento que se pueda ocultar al minimizar la barra -->

<body>

<form class="form-horizontal" role="form" id="form1" name="form1" method="post" action="">
 <table width="100" border="1" class="table table-striped">
	      <tr>
	        <td width="42%"> 
            <input type="text" name="placa" class="form-control" id="placa"
             placeholder="Placa" value="<?php echo htmlentities($row_Recordset1['placa'], ENT_COMPAT, ''); ?>" >
             
            </td>
	        <td width="58%"><input type="text" name="marca" class="form-control" id="marca"
             placeholder="Marca" value="<?php echo htmlentities($row_Recordset1['marca'], ENT_COMPAT, ''); ?>"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="modelo" class="form-control" id="marca"
             placeholder="Modelo" value="<?php echo htmlentities($row_Recordset1['modelo'], ENT_COMPAT, ''); ?>" ></td>
	        <td><input type="text" name="numero_motor" class="form-control" id="marca"
             placeholder="Numero Motor" value="<?php echo htmlentities($row_Recordset1['numero_motor'], ENT_COMPAT, ''); ?>"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="serie_motor" class="form-control" id="marca"
             placeholder="Serie Motor" value="<?php echo htmlentities($row_Recordset1['serie_motor'], ENT_COMPAT, ''); ?>"></td>
	        <td><input type="text" name="color_vehiculo" class="form-control" id="marca"
             placeholder="Color Vehiculo" value="<?php echo htmlentities($row_Recordset1['color_vehiculo'], ENT_COMPAT, ''); ?>"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="capacidad" class="form-control" id="marca"
             placeholder="Capacidad" value="<?php echo htmlentities($row_Recordset1['capacidad'], ENT_COMPAT, ''); ?>"></td>
	        <td><input type="text" name="numero_ejes" class="form-control" id="marca"
             placeholder="Numero De Ejes" value="<?php echo htmlentities($row_Recordset1['numero_ejes'], ENT_COMPAT, ''); ?>"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="tarjeta" class="form-control" id="marca"
             placeholder="Tarjeta Propiedad" value="<?php echo htmlentities($row_Recordset1['tarjeta'], ENT_COMPAT, ''); ?>"></td>
	        <td><input type="text" name="soat_numero" class="form-control" id="marca"
             placeholder="Soat Numero" value="<?php echo htmlentities($row_Recordset1['soat_numero'], ENT_COMPAT, ''); ?>"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="fechav_soat" class="form-control" id="marca"
             placeholder="Fecha Vencimiento Soat"  value="<?php echo htmlentities($row_Recordset1['fechav_soat'], ENT_COMPAT, ''); ?>"></td>
	        <td><input type="text" name="valor_soat" class="form-control" id="marca"
             placeholder="Valor Soat" value="<?php echo htmlentities($row_Recordset1['valor_soat'], ENT_COMPAT, ''); ?>"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="compania_soat" class="form-control" id="marca" placeholder="Compañia Soat" value="<?php echo htmlentities($row_Recordset1['compania_soat'], ENT_COMPAT, ''); ?>" size="32" /></td>
	        <td>&nbsp;<input name="regrc" type="submit" class="btn btn-primary" value="Actualizar Informacion" id="regrc"></td>
          </tr>
</table>
   <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="id" value="<?php echo $row_Recordset1['id']; ?>" />
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
