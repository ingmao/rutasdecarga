<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registro</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="banner"> 
			<div id="logotext">Modelo de Optimización <br> del transporte de carga<br> en Antioqui y Eje Cafetero</div>
</div>
<form method="post" action="registration.php">
            <center>
            <table border="0" width="30%" cellpadding="">
                <thead>
                    <tr>
                        <th colspan="2">Ingrese su Infromación</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Nombre y Apellido</td>
                        <td><input type="text" name="fname" value="" /></td>
                    </tr>
                    <tr>
                        <td>Nombre de usuario</td>
                        <td><input type="text" name="uname" value="" /></td>
                    </tr>
                    <tr>
                        <td>Clave</td>
                        <td><input type="password" name="pass" value="" /></td>
                    </tr>
                    <tr>
                        <td><input type="submit" value="Submit" name="reg" id="reg" /></td>
                        <td><input type="reset" value="Reset" /></td>
                    </tr>
                    <tr>
                        <td colspan="2"><div class="regresar">Ya registrado!!  <a href="index.php">Entre aquí</a></div></td>
                    </tr>
                </tbody>
            </table>
            </center>
        </form>
        
</body>
</html>