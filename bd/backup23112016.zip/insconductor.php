<?php 
require('clases/funciones.php');

$objeto=new Funciones();


if(isset($_POST['regrc'])){
	$campos[0]=trim($_POST['documento']);
	$campos[1]=trim($_POST['nombres']);
	$campos[2]=trim($_POST['apellidos']);
	$campos[3]=trim($_POST['direccion']);
	$campos[4]=trim($_POST['telefono']);
	$campos[5]=trim($_POST['email']);
	$campos[6]=trim($_POST['tarjeta_conduccion']);
	$campos[7]=trim($_POST['categoria_conduccion']);
	$campos[8]=trim($_POST['fecha_vencimiento_tarjeta']);
	$campos[9]=trim($_POST['fecha_nacimiento']);
    $campos[10]=trim($_POST['estado_civil']);
	
	
	
	if($objeto->inserconductor($campos)==true){
		header("location:insconductor.php");
		}else{
			 echo "<script language='javascript'>
		             alert('Se produjo un error. Intente nuevamente')
		           </script>";
			}
	
	}
?>



<!DOCTYPE html>
<html>
<head>

<meta name="description" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1">

	    <link rel="stylesheet" href="css/bootstrap.min.css">
	    

  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" type="text/css" href="bootstrap-social.css">

<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<script type="text/javascript" src="js/jquery.mobile.customized.min.js"></script>
		<script type="text/javascript" src="js/jquery.easing.1.3.js"></script> 
		<script type="text/javascript" src="js/camera.min.js"></script>
		<script type="text/javascript" src="js/myscript.js"></script>
		<script src="js/sorting.js" type="text/javascript"></script>
		<script src="js/jquery.isotope.js" type="text/javascript"></script>

		

		

	  
	<title></title>


	
			

</head>

<body class="as">



<!-- Agrupar los enlaces de navegación, los formularios y cualquier
       otro elemento que se pueda ocultar al minimizar la barra --><center><h2></h2></center>
<form class="form-horizontal" role="form" id="form1" name="form1" method="post" action="">
 <table width="100" border="1" class="table table-striped">
	      <tr>
	        <td width="42%"> 
            <input type="text" name="documento" class="form-control" id="documento"
             placeholder="documento">
             
            </td>
	        <td width="58%"><input type="text" name="nombres" class="form-control" id="nombres"
             placeholder="Nombres"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="apellidos" class="form-control" id="apellidos"
             placeholder="Apellidos"></td>
	        <td><input type="text" name="direccion" class="form-control" id="direccion"
             placeholder="direccion"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="telefono" class="form-control" id="telefono"
             placeholder="Telefono"></td>
	        <td><input type="text" name="email" class="form-control" id="email"
             placeholder="Email"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="tarjeta_conduccion" class="form-control" id="tarjeta_conduccion"
             placeholder="Tarjeta_conduccion"></td>
	        <td><input type="text" name="categoria_conduccion" class="form-control" id="categoria_conduccion"
             placeholder="Categoria Conduccion"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="fecha_vencimiento_tarjeta" class="form-control" id="fecha_vencimiento_tarjeta"
             placeholder="Fecha vencimiento tarjeta"></td>
             
	        <td><input type="text" name="fecha_nacimiento" class="form-control" id="fecha_nacimiento"
             placeholder="Fecha nacimiento"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="estado_civil" class="form-control" id="estado_civil"
             placeholder="Estado civil"></td>
	        
          	   
	       
            
	        <td>&nbsp;<input name="regrc" type="submit" class="btn btn-primary" value="Guardar   Informacion" id="regrc"></td>
          </tr>
</table>
  
</form>



  


	 



<script type="text/javascript" src="js/vendor/jquery-1.11.0.min.js"></script>
	   
<script type="text/javascript" src="js/vendor/bootstrap.min.js"></script>


</body>
</html>