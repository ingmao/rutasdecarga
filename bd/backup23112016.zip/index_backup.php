<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Modelo de Optimización
del transporte de carga
en Antioqui y Eje Cafetero  </title>
       <link rel="stylesheet" href="css/style.css" />
    </head>
    <body>
        <div class="banner"> <div id="logotext">Modelo de Optimización <br> del transporte de carga<br> en Antioqui y Eje Cafetero </div>
            <form method="post" action="login.php" >

                <table border="0" width="30%" cellpadding="" align="right">
                    <thead>
                        <tr>
                            <th colspan="4">Entre aquí</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>

                            <td>Nombre de usuario <br><input type="text" name="uname" value="" /></td>
                            <td>Password<br><input type="password" name="pass" value="" /></td>
                            <td><input type="submit" value="Login" name="login"/></td>
                            <td><input type="reset" value="Reset" /></td>
                        </tr>
                        <tr>
                            <td colspan="4">No se ha registrado !!!!<a href="reg.php">Registrese aquí</a></td> 
                        </tr>

                    </tbody>
                </table>
            </form>
        </div>
        <div id="servicios">
            <hr>MODELO DE SIMULACIÓN </hr>
            <ul>
                <li>LOGÍSTICO</li>
                <li>RUTAS DE TRANSPORTE</li>
                <li>OPTIMIZACION DE RUTAS</li>
                <li>COSTO DE TRANSPORTE</li>
                <li>COSTO DE TIEMPOS</li>
                
            </ul>

        </div>
        <div id="publicidad">
        <!--<img src="img/giphy-1.gif" style="width: 200px; height: 150px;"/>
        <img src="img/cubo2.gif" style="width: 200px; height: 150px;"/>
        <img src="img/2rr9tag.gif" style="width: 200px; height: 150px;"/>
        <img src="img/anim_multi_pts_2.gif" style="width: 200px; height: 150px;"/>-->
        </div>
       
        <div style="width:100%;"  align="center" id="servicios">
        <footer>
  				<p>(c) <?php echo date("Y");?></p>
		</footer
></div>
    </body>
</html>