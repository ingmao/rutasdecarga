<?php 
require('clases/funciones.php');

$objeto=new Funciones();


if(isset($_POST['regrc'])){
	$campos[0]=trim($_POST['nit']);
	$campos[1]=trim($_POST['nombre']);
	$campos[2]=trim($_POST['telefono']);
	$campos[3]=trim($_POST['direccion']);
	$campos[4]=trim($_POST['email']);
		
	
	
	if($objeto->insertaller($campos)==true){
		header("location:taller.php");
		}else{
			 echo "<script language='javascript'>
		             alert('Se produjo un error. Intente nuevamente')
		           </script>";
			}
	
	}
?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" type="text/css" href="bootstrap-social.css">

<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<script type="text/javascript" src="js/jquery.mobile.customized.min.js"></script>
		<script type="text/javascript" src="js/jquery.easing.1.3.js"></script> 
		<script type="text/javascript" src="js/camera.min.js"></script>
		<script type="text/javascript" src="js/myscript.js"></script>
		<script src="js/sorting.js" type="text/javascript"></script>
		<script src="js/jquery.isotope.js" type="text/javascript"></script>

		



<title>Taller</title>
</head>

<center>
  <h2>INGRESO  TALLER</h2><br><br></center>
<form class="form-horizontal" role="form" id="form1" name="form1" method="post" action="">
 <table width="100" border="1" class="table table-striped">
	      <tr>
	        <td width="42%"> 
            <input type="text" name="nit" class="form-control" id="documento"
             placeholder="Nit taller">
             
            </td>
	        <td width="58%"><input type="text" name="nombre" class="form-control" id="nombres"
             placeholder="Nombre taller"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="telefono" class="form-control" id="apellidos"
             placeholder="telefono"></td>
	        <td><input type="text" name="direccion" class="form-control" id="direccion"
             placeholder="direccion"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="email" class="form-control" id="telefono"
             placeholder="Email"></td>
             
	        <td><input name="regrc" type="submit" class="btn btn-primary" value="Guardar   Informacion" id="regrc"></td>
        
	        
	      	              
                     
	        <td>&nbsp;</td>
          </tr>
</table>
  
</form>



  


	 



<script type="text/javascript" src="js/vendor/jquery-1.11.0.min.js"></script>
	   
<script type="text/javascript" src="js/vendor/bootstrap.min.js"></script>


<body>
</body>
</html>