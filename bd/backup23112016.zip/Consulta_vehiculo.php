<?php require_once('Connections/conexion.php'); ?>
<?php //include 'main.php';?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_Recordset1 = 10;
$pageNum_Recordset1 = 0;
if (isset($_GET['pageNum_Recordset1'])) {
  $pageNum_Recordset1 = $_GET['pageNum_Recordset1'];
}
$startRow_Recordset1 = $pageNum_Recordset1 * $maxRows_Recordset1;

mysql_select_db($database_conexion, $conexion);
$query_Recordset1 = "SELECT id, placa, marca, modelo, capacidad, numero_ejes FROM vehiculo1";
$query_limit_Recordset1 = sprintf("%s LIMIT %d, %d", $query_Recordset1, $startRow_Recordset1, $maxRows_Recordset1);
$Recordset1 = mysql_query($query_limit_Recordset1, $conexion) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);

if (isset($_GET['totalRows_Recordset1'])) {
  $totalRows_Recordset1 = $_GET['totalRows_Recordset1'];
} else {
  $all_Recordset1 = mysql_query($query_Recordset1);
  $totalRows_Recordset1 = mysql_num_rows($all_Recordset1);
}
$totalPages_Recordset1 = ceil($totalRows_Recordset1/$maxRows_Recordset1)-1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="description" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/bootstrap.min.css">
	    

  <link rel="stylesheet" href="css/main.css">


<link rel="stylesheet" href="js/jquery-ui-1.12.1.custom/jquery-ui.css">
<script type="text/javascript" src="js/jquery-3.1.1.js"></script>
<script src="js/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script type="text/javascript" src="js/jquery-ui-timepicker-addon.js"></script>
	

	   

		<script type="text/javascript" src="js/jquery-3.1.1.js"></script>
<script src="js/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script type="text/javascript" src="js/jquery-ui-timepicker-addon.js"></script>

		

	  
	<title></title>


<script language=javascript>
function ventanaSecundaria (URL){
   window.open(URL,"ventana1","width=720,height=590,scrollbars=NO")
}
</script>
			

</head>

<body class="as">



<!-- Agrupar los enlaces de navegación, los formularios y cualquier
       otro elemento que se pueda ocultar al minimizar la barra --><center><h2></h2>

<body>
<table width="100%"  style="font-size:17px" class="table table-striped ">
  <tr>
    <td  class="success" >id</td>
    <td >Placa</td>
    <td >Marca</td>
    <td>Modelo</td>
    <td>Capacidad</td>
    <td>Ejes</td>
    <td>Modificar</td>
      <td>Ver Mas</td>
  </tr>
  <?php do { ?>
    <tr>
      <td class="active"><?php echo $row_Recordset1['id']; ?></td>
      <td class="success"><?php echo $row_Recordset1['placa']; ?></td>
      <td class="success"><?php echo $row_Recordset1['marca']; ?></td>
      <td  class="success"><?php echo $row_Recordset1['modelo']; ?></td>
      <td class="success"><?php echo $row_Recordset1['capacidad']; ?></td>
      <td  class="success"><?php echo $row_Recordset1['numero_ejes']; ?></td>
       <td  class="success"><a href="Modificar_vehiculo.php?id=<?php echo $row_Recordset1['id']; ?>">Modificar</a></td>
      
      <td  class="success"><a href="javascript:ventanaSecundaria('Detalle_vehiculo.php?id=<?php echo $row_Recordset1['id']; ?>')"><img src="img/ver.jpeg" width="35" height="35" /></a></td>
       <td width="15"></td></tr>
    <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
