<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/metisMenu.min.css" rel="stylesheet">
    <link href="css/sb-admin-2.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
<script src="js/jquery-3.1.1.js"></script>
<script type="text/javascript">
jQuery(document).ready(function(){
$('#side-menu').click(function(e){
	var id = e.target.id;
	switch(id) {
		case "registroruta":
		$.get('registroruta.php', function(result) {
			$('#page-wrapper').empty();
			$('#page-wrapper').append(result);
		});
		break;
		case "consultarutas":
			$.get('consultarutas.php', function(result) {
			$('#page-wrapper').empty();
			$('#page-wrapper').append(result);
		});
		break;
		case "insve":
			$.get('insve.php', function(result) {
			$('#page-wrapper').empty();
			$('#page-wrapper').append(result);
		});
		break;
		case "Consulta_vehiculo":
			$.get('Consulta_vehiculo.php', function(result) {
			$('#page-wrapper').empty();
			$('#page-wrapper').append(result);
		});
		break;
		case "insconductor":
			$.get('insconductor.php', function(result) {
			$('#page-wrapper').empty();
			$('#page-wrapper').append(result);
		});
		break;
		case "Consulta_conductor":
			$.get('Consulta_conductor.php', function(result) {
			$('#page-wrapper').empty();
			$('#page-wrapper').append(result);
		});
		
		break;
			case "taller":
			$.get('taller.php', function(result) {
			$('#page-wrapper').empty();
			$('#page-wrapper').append(result);
		});
		break;
		case "Consulta_taller":
			$.get('Consulta_taller.php', function(result) {
			$('#page-wrapper').empty();
			$('#page-wrapper').append(result);
		});
		
		break;
		case "rutasgenerales":
			$('#page-wrapper').empty();
			$('#page-wrapper').append('<div class="container"><div class="embed-responsive embed-responsive-16by9"><iframe class="embed-responsive-item" src="rutasgenerales.php" onload="this.width=screen.width;this.height=screen.height;"></iframe></div></div>');
		break;
		default:$('#page-wrapper').empty();
	}

});
<?php if(isset($_GET['cod'])){?>

$.get('consultarutas.php?cod=<?php if(isset($_GET['cod'])){echo $_GET['cod'];} ?>', function(result) {
	$('#page-wrapper').empty();
    $('#page-wrapper').append(result);
});
<?php } ?>
});
</script>
</head>

<body>

    <div id="wrapper">

        
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Motcatec Admin</a>
            </div>
           

            <ul class="nav navbar-top-links navbar-right">
                 <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Ajustes</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                </li>
            </ul>

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="#"><i class="fa fa-map-marker fa-fw"></i> Ruta<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="#" id="registroruta"><i class='fa fa-car fa-fw'></i> Agregar Ruta</a>
                                </li>
                                <li>
                                    <a href="#" id="consultarutas"><i class='fa fa-map-marker fa-fw'></i> Consultar Rutas</a>
                                </li>
								<li>
                                      <a href="#" id="rutasgenerales"><i class='fa fa-map-marker fa-fw'></i>Rutas Programadas</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-truck fa-fw"></i> Camion<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="#" id="insve"><i class='fa fa-car fa-fw'></i> Agregar Camion</a>
                                </li>
                                <li>
                                    <a href="#" id="Consulta_vehiculo"><i class='fa fa-list-ol fa-fw'></i> Consultar Camion</a>
                                </li>
                            </ul>
                        </li>
                        
                        <li>
                            <a href="#"><i class="fa fa-male" aria-hidden="true"></i> Conductores<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="#" id="insconductor"><i class='fa fa-car fa-fw'></i> Agregar Conductor</a>
                                </li>
                                <li>
                                    <a href="#" id="Consulta_conductor"><i class='fa fa-map-marker fa-fw'></i> Consultar Conductor</a>
                                </li>
								
                            </ul>
                        </li>
						
						 <li>
                            <a href="#"><i class="fa fa-taxi" aria-hidden="true"></i>Taller<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="#" id="taller"><i class='fa fa-car fa-fw'></i> Agregar Taller</a>
                                </li>
                                <li>
                                    <a href="#" id="Consulta_taller"><i class='fa fa-map-marker fa-fw'></i> Consultar Taller</a>
                                </li>
								
                            </ul>
                        </li>


                        <!--<li>
                            <a href="#"><i class="fa fa-child fa-fw"></i> Genero<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="#"><i class='fa fa-plus fa-fw'></i> Agregar</a>
                                </li>
                                <li>
                                    <a href="#"><i class='fa fa-list-ol fa-fw'></i> Generos</a>
                                </li>
                            </ul>
                        </li>-->

                    </ul>
                </div>
            </div>

     </nav>

        <div id="page-wrapper">
            
        </div>

    </div>
    

    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/metisMenu.min.js"></script>
    <script src="js/sb-admin-2.js"></script>

</body>

</html>
