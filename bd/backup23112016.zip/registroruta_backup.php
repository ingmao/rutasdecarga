<?php 
require('clases/funciones.php');
include 'main.php';
$objeto=new Funciones();


if(isset($_POST['regrc'])){
	$campos[0]=htmlspecialchars(trim($_POST['origen']));
	$campos[1]=htmlspecialchars(trim($_POST['destino']));
	$campos[2]=htmlspecialchars(trim($_POST['tpcm']));
	$campos[3]=htmlspecialchars(trim($_POST['tpcarg']));
	$campos[4]=htmlspecialchars(trim($_POST['fechsalhr']));
	$campos[5]=htmlspecialchars(trim($_POST['fechlleghr']));
	if($objeto->insertarrutas($campos)==true){
		header("location:consultarutas.php?cod=".mysql_insert_id());
		}else{
			 echo "<script language='javascript'>
		             alert('Se produjo un error. Intente nuevamente')
		           </script>";
			}
	
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Registro de rutas </title>
<link rel="stylesheet" href="js/jquery-ui-1.12.1.custom/jquery-ui.css">
<script type="text/javascript" src="js/jquery-3.1.1.js"></script>
<script src="js/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script type="text/javascript" src="js/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript">
jQuery().ready(function(){
$.datepicker.regional['es'] = {
 closeText: 'Cerrar',
 prevText: '<Ant',
 nextText: 'Sig>',
 currentText: 'Hoy',
 monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
 monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
 dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
 dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
 dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
 weekHeader: 'Sm',
 dateFormat: 'dd/mm/yy',
 firstDay: 1,
 isRTL: false,
 showMonthAfterYear: false,
 yearSuffix: ''
 };
 $.datepicker.setDefaults($.datepicker.regional['es']);
$(function(){
	$('#fechsalhr').datetimepicker({
					showSecond: true,
					dateFormat: "yy-mm-dd",
					timeFormat: 'hh:mm:ss'
					
				});
		$('#fechlleghr').datetimepicker({
					showSecond: true,
					dateFormat: "yy-mm-dd",
					timeFormat: 'hh:mm:ss'
					
				});
	});
});
</script>	
</head>

<body>
<div>
  <form id="form1" name="form1" method="post" action="">
    <table width="100%" border="0" align="center">
      <tr>
        <th colspan="4" align="left" scope="col">Registro de ruta</th>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Origen</td>
        <td><label for="origen"></label>
        <input type="text" name="origen" id="origen" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Destino</td>
        <td><label for="destino"></label>
        <input type="text" name="destino" id="destino" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Tipo de camion</td>
        <td><label for="tpcm"></label>
        <input type="text" name="tpcm" id="tpcm" />          <label for="fechsalhr"></label></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Tipo de Carga</td>
        <td><label for="tpcarg"></label>
        <input type="text" name="tpcarg" id="tpcarg" />          <label for="fechlleghr"></label></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Fecha Hora de Salida</td>
        <td><input type="text" name="fechsalhr" id="fechsalhr" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Fecha Hora de Llegada</td>
        <td><input type="text" name="fechlleghr" id="fechlleghr" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr align="center">
        <td colspan="4"><input type="submit" name="regrc" id="regrc" value="Enviar" /></td>
      </tr>
    </table>
  </form>

</div>


</body>
</html>