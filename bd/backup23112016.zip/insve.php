<?php 
require('clases/funciones.php');
//include 'main.php';
$objeto=new Funciones();


if(isset($_POST['regrc'])){
	$campos[0]=trim($_POST['placa']);
	$campos[1]=trim($_POST['marca']);
	$campos[2]=trim($_POST['modelo']);
	$campos[3]=trim($_POST['numero_motor']);
	$campos[4]=trim($_POST['serie_motor']);
	$campos[5]=trim($_POST['color_vehiculo']);
	$campos[6]=trim($_POST['capacidad']);
	$campos[7]=trim($_POST['numero_ejes']);
	$campos[8]=trim($_POST['tarjeta']);
	$campos[9]=trim($_POST['soat_numero']);
    $campos[10]=trim($_POST['fechav_soat']);
	$campos[11]=trim($_POST['valor_soat']);
	$campos[12]=trim($_POST['compania_soat']);
	
	
	
	if($objeto->inservehiculo1($campos)==true){
		header("location:insve.php");
		}else{
			 echo "<script language='javascript'>
		             alert('Se produjo un error. Intente nuevamente')
		           </script>";
			}
	
	}
?>



<!DOCTYPE html>
<html>
<head>

<meta name="description" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" href="js/jquery-ui-1.12.1.custom/jquery-ui.css">
<script type="text/javascript" src="js/jquery-3.1.1.js"></script>
<script src="js/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script type="text/javascript" src="js/jquery-ui-timepicker-addon.js"></script>
	

	   

		<script type="text/javascript" src="js/jquery-3.1.1.js"></script>
<script src="js/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script type="text/javascript" src="js/jquery-ui-timepicker-addon.js"></script>

	  
	<title></title>


	
			

</head>

<body class="as">


<!-- Agrupar los enlaces de navegación, los formularios y cualquier
       otro elemento que se pueda ocultar al minimizar la barra --><center><h2>INGRESO DE VEHICULOS</h2><br><br></center>
<form class="form1" role="form" id="form1" name="form1" method="post" action="">
 <table width="100" border="1" class="table table-striped">
	      <tr>
	        <td width="42%"> 
            <input type="text" name="placa" class="form-control" id="placa"
             placeholder="Placa">
             
            </td>
	        <td width="58%"><input type="text" name="marca" class="form-control" id="marca"
             placeholder="Marca"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="modelo" class="form-control" id="marca"
             placeholder="Modelo"></td>
	        <td><input type="text" name="numero_motor" class="form-control" id="marca"
             placeholder="Numero Motor"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="serie_motor" class="form-control" id="marca"
             placeholder="Serie Motor"></td>
	        <td><input type="text" name="color_vehiculo" class="form-control" id="marca"
             placeholder="Color Vehiculo"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="capacidad" class="form-control" id="marca"
             placeholder="Capacidad"></td>
	        <td><input type="text" name="numero_ejes" class="form-control" id="marca"
             placeholder="Numero De Ejes"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="tarjeta" class="form-control" id="marca"
             placeholder="Tarjeta Propiedad"></td>
	        <td><input type="text" name="soat_numero" class="form-control" id="marca"
             placeholder="Soat Numero"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="fechav_soat" class="form-control" id="marca"
             placeholder="Fecha Vencimiento Soat"></td>
	        <td><input type="text" name="valor_soat" class="form-control" id="marca"
             placeholder="Valor Soat"></td>
          </tr>
	      <tr>
	        <td><input type="text" name="compania_soat" class="form-control" id="marca"
             placeholder="Compañia Soat"></td>
	        <td>&nbsp;<input name="regrc" type="submit" class="btn btn-primary" value="Guardar   Informacion" id="regrc"></td>
          </tr>
</table>
  
</form>



  


	 



<script type="text/javascript" src="js/vendor/jquery-1.11.0.min.js"></script>
	   
<script type="text/javascript" src="js/vendor/bootstrap.min.js"></script>


</body>
</html>