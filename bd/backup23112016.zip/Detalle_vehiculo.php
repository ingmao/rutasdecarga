<?php require_once('Connections/conexion.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conexion, $conexion);
$query_Recordset1 = "SELECT * FROM vehiculo1";
$Recordset1 = mysql_query($query_Recordset1, $conexion) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);$colname_Recordset1 = "-1";
if (isset($_GET['id'])) {
  $colname_Recordset1 = $_GET['id'];
}
mysql_select_db($database_conexion, $conexion);
$query_Recordset1 = sprintf("SELECT * FROM vehiculo1 WHERE id = %s", GetSQLValueString($colname_Recordset1, "int"));
$Recordset1 = mysql_query($query_Recordset1, $conexion) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/bootstrap.min.css">
	    

  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" type="text/css" href="bootstrap-social.css">

<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<script type="text/javascript" src="js/jquery.mobile.customized.min.js"></script>
		<script type="text/javascript" src="js/jquery.easing.1.3.js"></script> 
		<script type="text/javascript" src="js/camera.min.js"></script>
		<script type="text/javascript" src="js/myscript.js"></script>
		<script src="js/sorting.js" type="text/javascript"></script>
		<script src="js/jquery.isotope.js" type="text/javascript"></script>

		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
		<link rel='stylesheet' id='camera-css'  href='css/camera.css' type='text/css' media='all'>

		

	  
	<title></title>


	
			

</head>

<body class="as">


<nav class="navbar navbar-leon" role="navigation">
  <!-- El logotipo y el icono que despliega el menú se agrupan
       para mostrarlos mejor en los dispositivos móviles -->
  <div class="navbar-header">
   
 
  </div>
</nav>
<!-- Agrupar los enlaces de navegación, los formularios y cualquier
       otro elemento que se pueda ocultar al minimizar la barra --><center><h2>DETALLE VEHICULO</h2>
  <table width="100%" class="table table-striped" style="font-size:17px">
    <tr>
      <td >Codigo:</td>
      <td ><?php echo $row_Recordset1['id']; ?></td>
      <td >Ejes:</td>
      <td ><?php echo $row_Recordset1['numero_ejes']; ?></td>
    </tr>
    <tr>
      <td>Placa:</td>
      <td><?php echo $row_Recordset1['placa']; ?></td>
      <td>Tarjeta:</td>
      <td><?php echo $row_Recordset1['tarjeta']; ?></td>
    </tr>
    <tr>
      <td>Marca:</td>
      <td><?php echo $row_Recordset1['marca']; ?></td>
      <td>N° Soat:</td>
      <td><?php echo $row_Recordset1['soat_numero']; ?></td>
    </tr>
    <tr>
      <td>Modelo:</td>
      <td><?php echo $row_Recordset1['modelo']; ?></td>
      <td>Fecha vencimiento:</td>
      <td><?php echo $row_Recordset1['fechav_soat']; ?></td>
    </tr>
    <tr>
      <td>Numero Motor:</td>
      <td><?php echo $row_Recordset1['numero_motor']; ?></td>
      <td>Valor:</td>
      <td><?php echo $row_Recordset1['valor_soat']; ?></td>
    </tr>
    <tr>
      <td>Serie Motor:</td>
      <td><?php echo $row_Recordset1['serie_motor']; ?></td>
      <td>Empresa:</td>
      <td><?php echo $row_Recordset1['compania_soat']; ?></td>
    </tr>
    <tr>
      <td>Color:</td>
      <td><?php echo $row_Recordset1['color_vehiculo']; ?></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>Capacidad:</td>
      <td><?php echo $row_Recordset1['capacidad']; ?></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <br><br></center>
<body>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
