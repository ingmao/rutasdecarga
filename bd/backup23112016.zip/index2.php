<?php require_once('Connections/conexion.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['uname'])) {
  $loginUsername=$_POST['uname'];
  $password=$_POST['pass'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "admin.php";
  $MM_redirectLoginFailed = "index.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_conexion, $conexion);
  
  $LoginRS__query=sprintf("SELECT us_usuario, us_password FROM rc_usuarios WHERE us_usuario=%s AND us_password=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $conexion) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Modelo de Optimización
del transporte de carga
en Antioqui y Eje Cafetero  </title>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-responsive.css" />
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" />
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="css/style.css" />
<script src="js/jquery-3.1.1.js"></script>		
<script src="bootstrap/js/bootstrap.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
    </head>
    <body>
    <div class="container-fluid">
        <div class="banner"> <div id="logotext" class="row">Modelo de Optimización  del transporte <br> de carga en Antioquia y Eje Cafetero </div>
            <div class="table-responsive"><form method="POST" action="<?php echo $loginFormAction; ?>" >

                <table border="0" width="30%" cellpadding="" align="right" class="table table-striped table-inverse">
                    <thead>
                        <tr>
                            <th colspan="4">Entre aquí</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>

                            <td>Nombre de usuario <br><input type="text" name="uname" value="" /></td>
                            <td>Password<br><input type="password" name="pass" value="" /></td>
                            <td><input type="submit" value="Login" name="login"/></td>
                            <td><input type="reset" value="Reset" /></td>
                        </tr>
                        <tr>
                            <td colspan="4">No se ha registrado !!!!<a href="reg.php">Registrese aquí</a></td> 
                        </tr>

                    </tbody>
                </table>
            </form></div>
        </div>
        <div id="servicios">
            <hr>MODELO DE SIMULACIÓN </hr>
            <ul>
                <li>LOGÍSTICO</li>
                <li>RUTAS DE TRANSPORTE</li>
                <li>OPTIMIZACION DE RUTAS</li>
                <li>COSTO DE TRANSPORTE</li>
                <li>COSTO DE TIEMPOS</li>
                
            </ul>

        </div>
        <div id="publicidad">
        <!--<img src="img/giphy-1.gif" style="width: 200px; height: 150px;"/>
        <img src="img/cubo2.gif" style="width: 200px; height: 150px;"/>
        <img src="img/2rr9tag.gif" style="width: 200px; height: 150px;"/>
        <img src="img/anim_multi_pts_2.gif" style="width: 200px; height: 150px;"/>-->
        </div>
       
        <div style="width:100%;"  align="center" id="servicios">
        <footer>
  				<p>(c) <?php echo date("Y");?></p>
		</footer
></div>
</div>
    </body>
</html>