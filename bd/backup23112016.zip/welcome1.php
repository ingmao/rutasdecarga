<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registro exitoso</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="banner"> 
			<div id="logotext">Modelo de Optimización <br> del transporte de carga<br> en Antioqui y Eje Cafetero</div>
</div>

         <div style="font-weight:bolder; font-size:28px;"><h1>El registro fue Existoso.<div><a href='index.php'>Ir al Inicio</a></div></h1></div>
</body>
</html>